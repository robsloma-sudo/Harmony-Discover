#!/usr/bin/env bash
# Uploads ONLY the branch fix/scanner-on-main. No pull request, merge or deploy.
set -euo pipefail
REPO_URL="https://github.com/robsloma-sudo/Harmony-Discover.git"
BUNDLE_FILE="${1:-fix-scanner-on-main.bundle}"
BRANCH="fix/scanner-on-main"
EXPECTED_HEAD="a459b9f838962015ee6c26a333c1fcfa926e949a"
EXPECTED_BASE="d65a9a9ed91fe5d9b62775fbbd0cbef5679bfab3"
BUNDLE_PATH="$(cd "$(dirname "$BUNDLE_FILE")" && pwd)/$(basename "$BUNDLE_FILE")"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
git clone --filter=blob:none --no-checkout "$REPO_URL" "$WORK/repo"
cd "$WORK/repo"
git fetch origin main
git fetch "$BUNDLE_PATH" "refs/heads/$BRANCH:refs/heads/$BRANCH"
[[ "$(git rev-parse "refs/heads/$BRANCH")" == "$EXPECTED_HEAD" ]] || { echo "ERROR: wrong bundle head" >&2; exit 1; }
git merge-base --is-ancestor "$EXPECTED_BASE" "refs/heads/$BRANCH" || { echo "ERROR: base missing" >&2; exit 1; }
if ! git merge-base --is-ancestor origin/main "refs/heads/$BRANCH"; then
  echo "STOP: main changed since this file was made. Nothing pushed. Tell Harmony." >&2; exit 2
fi
git push origin "refs/heads/$BRANCH:refs/heads/$BRANCH"
[[ "$(git ls-remote origin "refs/heads/$BRANCH" | awk '{print $1}')" == "$EXPECTED_HEAD" ]] || { echo "ERROR: remote check failed" >&2; exit 1; }
echo "SUCCESS: $BRANCH is on GitHub at $EXPECTED_HEAD. Nothing merged or deployed."
