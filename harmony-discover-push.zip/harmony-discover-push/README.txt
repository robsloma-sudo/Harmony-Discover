Upload ONLY to a new branch, never to main (a new upload on main makes the script stop).
In a GitHub Codespace terminal, in the folder with both files:
  bash push-branch.sh fix-scanner-on-main.bundle
Expected result: SUCCESS ... a459b9f...  No pull request, merge or deploy.
