Harmony Discover — safe GitHub branch upload

Files needed:
- fix-scanner-on-main.bundle (the 28 MB bundle already recovered in this ChatGPT conversation)
- push-branch.sh

Goal:
Upload the complete 351-commit history to robsloma-sudo/Harmony-Discover as
fix/scanner-on-main. This does NOT create a PR, merge anything, deploy Netlify,
or modify Supabase.

Run from a GitHub Codespace terminal after placing both files in the same folder:
  bash push-branch.sh fix-scanner-on-main.bundle

Prerequisites:
- git and GitHub CLI (gh)
- Authenticate with: gh auth login
- The GitHub account must have push access to robsloma-sudo/Harmony-Discover

Safety checks in the script:
- Verifies the imported branch head is exactly
  20ebccbd2fb8c4da35031600ac815ef6545e6f51
- Verifies expected main ancestor 027d2c4733d806dd2119e36ae99e1941f541d9b9
- Verifies current origin/main is an ancestor of the branch before pushing
- Uses a normal non-force push to ONLY refs/heads/fix/scanner-on-main
- Verifies the remote branch head after push
- Stops without pushing if main has advanced beyond the bundle

If it stops because main advanced, do not force-push or merge. Bring the
updated main history into a fresh audit before deciding the next step.
