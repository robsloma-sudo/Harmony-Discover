#!/usr/bin/env bash
set -euo pipefail

REPO_URL="https://github.com/robsloma-sudo/Harmony-Discover.git"
BUNDLE_FILE="${1:-fix-scanner-on-main.bundle}"
BRANCH="fix/scanner-on-main"
EXPECTED_HEAD="20ebccbd2fb8c4da35031600ac815ef6545e6f51"
EXPECTED_BASE="027d2c4733d806dd2119e36ae99e1941f541d9b9"

if ! command -v git >/dev/null 2>&1; then echo "ERROR: git is not installed." >&2; exit 1; fi
if ! command -v gh >/dev/null 2>&1; then echo "ERROR: GitHub CLI (gh) is not installed." >&2; exit 1; fi
if [[ ! -f "$BUNDLE_FILE" ]]; then echo "ERROR: Bundle not found: $BUNDLE_FILE" >&2; exit 1; fi
BUNDLE_PATH="$(cd "$(dirname "$BUNDLE_FILE")" && pwd)/$(basename "$BUNDLE_FILE")"

gh auth status
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo "Cloning repository metadata and current main..."
git clone --filter=blob:none --no-checkout "$REPO_URL" "$WORK/repo"
cd "$WORK/repo"
git fetch origin main

echo "Importing the verified bundle..."
git fetch "$BUNDLE_PATH" "refs/heads/$BRANCH:refs/heads/$BRANCH"
ACTUAL_HEAD="$(git rev-parse "refs/heads/$BRANCH")"
if [[ "$ACTUAL_HEAD" != "$EXPECTED_HEAD" ]]; then
  echo "ERROR: Unexpected bundle head: $ACTUAL_HEAD" >&2; exit 1
fi

if ! git cat-file -e "$EXPECTED_BASE^{commit}" 2>/dev/null; then
  echo "ERROR: Expected base commit is missing from imported history." >&2; exit 1
fi
if ! git merge-base --is-ancestor "$EXPECTED_BASE" "refs/heads/$BRANCH"; then
  echo "ERROR: Expected main ancestor is not in the branch history." >&2; exit 1
fi
if ! git merge-base --is-ancestor origin/main "refs/heads/$BRANCH"; then
  echo "STOP: Remote main has commits not contained in this bundle. No push performed." >&2
  echo "A fresh integration review is required; do not force-push." >&2
  exit 2
fi

echo "Pre-push checks passed. Uploading ONLY $BRANCH (no PR, merge, or deployment)..."
git push origin "refs/heads/$BRANCH:refs/heads/$BRANCH"
echo "Verifying remote branch head..."
REMOTE_HEAD="$(git ls-remote origin "refs/heads/$BRANCH" | awk '{print $1}')"
if [[ "$REMOTE_HEAD" != "$EXPECTED_HEAD" ]]; then
  echo "ERROR: Remote head verification failed. Expected $EXPECTED_HEAD, got ${REMOTE_HEAD:-<missing>}." >&2
  exit 1
fi
echo "SUCCESS: https://github.com/robsloma-sudo/Harmony-Discover/tree/$BRANCH"
echo "Remote head: $REMOTE_HEAD"
echo "No pull request, merge, Netlify deployment, or Supabase change was made."
